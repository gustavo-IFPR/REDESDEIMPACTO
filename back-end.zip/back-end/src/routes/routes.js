import { Router } from "express";
import db from '../db/mysql.js';
import multer from 'multer';
import nodemailer from 'nodemailer';

const app = Router();

const storage = multer.memoryStorage();
const upload = multer({ storage: storage }).single('avatar');

// Rota para obter os ramos
app.get('/ramos', (req, res) => {
    db.query('SELECT id, ramo FROM ramos', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Erro ao buscar ramos.' });
        }
        res.json(results);
    });
});

// Rota para cadastrar um negócio
app.post('/cadastrar', (req, res) => {
    const { nome, email, senha, cidade, ramo_id } = req.body;

    if (!nome || !email || !senha || !cidade || !ramo_id) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios.' });
    }

    // Insere o usuário no banco de dados
    const sql = 'INSERT INTO negocios (nome, cidade, senha, email, ramos_id) VALUES (?, ?, ?, ?, ?)';
    db.query(sql, [nome, cidade, senha, email, ramo_id], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Erro ao cadastrar o negócio.' });
        }
        res.status(201).json({ message: 'Cadastro realizado com sucesso!' });
    });
});

//Rota para login
app.post('/login', async (req, res) => {
    const { email, senha } = req.body;

    if (!email || !senha) {
        return res.status(400).json({ message: 'E-mail e senha são obrigatórios.' });
    }

    try {
        // Consultar o banco de dados para verificar as credenciais
        const [results] = await db.promise().query(
            'SELECT id, nome, email FROM negocios WHERE email = ? AND senha = ?',
            [email, senha]
        );

        if (results.length === 0) {
            return res.status(401).json({ message: 'E-mail ou senha inválidos.' });
        }

        // Retornar os dados do usuário autenticado
        const user = results[0];
        res.json(user);
    } catch (error) {
        console.error("Erro ao realizar login:", error);
        res.status(500).json({ message: 'Erro interno do servidor.' });
    }
});

//Rota para pegar as informações e carregar no perfil
app.get('/perfil', async (req, res) => {
    const { id } = req.query; // Assume que o ID do usuário está sendo enviado como query param

    if (!id) {
        return res.status(400).json({ message: 'ID é obrigatório para carregar o perfil.' });
    }

    try {
        // Busca o perfil pelo ID
        const [result] = await db.promise().query(
            'SELECT * FROM negocios WHERE id = ?',
            [id]
        );

        if (result.length === 0) {
            return res.status(404).json({ message: 'Usuário não encontrado.' });
        }

        res.json(result[0]); // Retorna os dados do perfil
    } catch (error) {
        console.error('Erro ao carregar perfil:', error);
        res.status(500).json({ message: 'Erro interno ao carregar o perfil.' });
    }
});

//Rota para atualizar o perfil
app.put('/perfil', async (req, res) => {
    upload(req, res, async (err) => {
        const {
            id,
            nome,
            cidade,
            senha,
            email,
            emailComercial,
            celular,
            site,
            redeSocial,
            ramo,
        } = req.body;

        if (!id) {
            return res.status(400).json({ message: 'ID é obrigatório para atualizar o perfil.' });
        }

        try {
            let avatar = null;

            // Verifica se um novo avatar foi enviado
            if (req.file) {
                avatar = req.file.buffer; // Novo avatar enviado
            } else {
                // Busca o avatar atual no banco de dados caso nenhum novo tenha sido enviado
                const [user] = await db.promise().query(
                'SELECT avatar FROM negocios WHERE id = ?',
                [id]
                );
                if (user.length > 0) {
                    avatar = user[0].avatar; // Mantém o avatar existente
                }
            }

            // Atualiza os dados no banco
            const query = `
                UPDATE negocios
                SET nome = ?, cidade = ?, senha = ?, email = ?, emailComercial = ?, celular = ?, site = ?, redeSocial = ?, avatar = ?, ramos_id = ?
                WHERE id = ?
            `;
            const params = [
                nome,
                cidade,
                senha,
                email,
                emailComercial,
                celular,
                site,
                redeSocial,
                avatar,
                ramo,
                id,
            ];

            await db.promise().query(query, params);

            res.json({ message: 'Perfil atualizado com sucesso.' });
        } catch (error) {
            console.error('Erro ao atualizar perfil:', error);
            res.status(500).json({ message: 'Erro interno ao atualizar o perfil.' });
        }
    });
});

//Rota de teste para salvar o contato no banco
app.post('/contato', async (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios.' });
    }

    try {
        const query = 'INSERT INTO contato (nome, email, mensagem) VALUES (?, ?, ?)';
        await db.promise().query(query, [name, email, message]);

        res.json({ message: 'Mensagem salva com sucesso!' });
    } catch (error) {
        console.error('Erro ao salvar mensagem:', error);
        res.status(500).json({ message: 'Erro ao salvar mensagem.' });
    }
});


//Rota para pegar as cidades
app.get('/cidades', async (req, res) => {
    try {
        const [cidades] = await db.promise().query('SELECT DISTINCT cidade FROM negocios');
        res.json(cidades.map(cidade => cidade.cidade));
    } catch (error) {
        console.error('Erro ao carregar cidades:', error);
        res.status(500).json({ message: 'Erro ao carregar cidades.' });
    }
});

//Rota para buscar negócios
app.post('/negocios', async (req, res) => {
    const { searchQuery, ramo, cidade } = req.body;

    try {
        let query = `
            SELECT n.id, n.nome, n.cidade, r.ramo, n.avatar, n.site, n.redeSocial, n.emailComercial, n.celular
            FROM negocios n
            LEFT JOIN ramos r ON n.ramos_id = r.id

            WHERE 1=1
        `;

        const params = [];

        if (searchQuery) {
            query += ' AND n.nome LIKE ?';
            params.push(`%${searchQuery}%`);
        }

        if (ramo) {
            query += ' AND r.id = ?';
            params.push(ramo);
        }

        if (cidade) {
            query += ' AND n.cidade = ?';
            params.push(cidade);
        }

        const [results] = await db.promise().query(query, params);

        // Converte o avatar (BLOB) para base64
        const businesses = results.map(business => ({
            ...business,
            avatar: business.avatar ? `data:image/jpeg;base64,${business.avatar.toString('base64')}` : null,
        }));

        res.json(businesses);
    } catch (error) {
        console.error('Erro ao buscar negócios:', error);
        res.status(500).json({ message: 'Erro ao buscar negócios.' });
    }
});

//Rota para excluir uma conta
app.delete('/excluir/', async (req, res) => {
    const { id } = req.body;

    if (!id) {
        return res.status(400).json({ message: 'ID do usuário é obrigatório.' });
    }

    try {
        const query = 'DELETE FROM negocios WHERE id = ?';
        const [result] = await db.promise().query(query, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Usuário não encontrado.' });
        }

        res.json({ message: 'Conta excluída com sucesso.' });
    } catch (error) {
        console.error('Erro ao excluir conta:', error);
        res.status(500).json({ message: 'Erro interno ao excluir a conta.' });
    }
});


export default app;