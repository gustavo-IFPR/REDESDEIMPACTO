import mysql from 'mysql2';

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '202027',
    database: 'redesDeImpacto',
});

export default db;